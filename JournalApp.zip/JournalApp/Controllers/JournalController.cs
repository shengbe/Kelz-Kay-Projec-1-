using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using JournalApp.Models;

namespace JournalApp.Controllers
{
    public class JournalController : Controller
    {
        private static List<JournalEntry> Entries = new List<JournalEntry>();
        private static string[] Prompts =
        {
            "Who was the most interesting person I interacted with today?",
            "What was the best part of my day?",
            "How did I see the hand of the Lord in my life today?",
            "What was the strongest emotion I felt today?",
            "If I had one thing I could do over today, what would it be?",
            "What is one thing I learned today?",
            "What is a goal I want to achieve this week?",
            "Describe a moment that made you smile today.",
            "What challenge did I face today and how did I handle it?",
            "Who or what am I grateful for today?"
        };
        
        private static string FilePath = Path.Combine(AppContext.BaseDirectory, "journal_entries.json");
        private static string CsvFilePath = Path.Combine(AppContext.BaseDirectory, "journal_entries.csv");

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult LoadJournal()
        {
            LoadJournalEntries();
            return View("Index", Entries);
        }

        public IActionResult Write()
        {
            ViewBag.Prompt = Prompts[new Random().Next(Prompts.Length)];
            return View();
        }

        [HttpPost]
        public IActionResult Write(string response, string prompt)
        {
            Entries.Add(new JournalEntry { Id = Guid.NewGuid(), Date = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), Prompt = prompt, Response = response });
            SaveJournal();
            return RedirectToAction("LoadJournal");
        }

        public IActionResult SaveToCSV()
        {
            try
            {
                using (var writer = new StreamWriter(CsvFilePath))
                {
                    writer.WriteLine("Id,Date,Prompt,Response");
                    foreach (var entry in Entries)
                    {
                        string csvEntry = $"{entry.Id},\"{entry.Date}\",\"{entry.Prompt.Replace("\"", "'")}\",\"{entry.Response.Replace("\"", "'")}\"";
                        writer.WriteLine(csvEntry);
                    }
                }
                TempData["Message"] = "Journal saved as CSV successfully.";
            }
            catch (Exception ex)
            {
                TempData["Message"] = "Error saving CSV: " + ex.Message;
            }
            return RedirectToAction("Index");
        }

        public IActionResult SaveToFile()
        {
            try
            {
                System.IO.File.WriteAllText(FilePath, JsonConvert.SerializeObject(Entries, Formatting.Indented));
                TempData["Message"] = "Journal saved successfully.";
            }
            catch (Exception ex)
            {
                TempData["Message"] = "Error saving journal: " + ex.Message;
            }
            return RedirectToAction("Index");
        }

        public IActionResult LoadFromFile()
        {
            try
            {
                if (System.IO.File.Exists(FilePath))
                {
                    string json = System.IO.File.ReadAllText(FilePath);
                    Entries = JsonConvert.DeserializeObject<List<JournalEntry>>(json) ?? new List<JournalEntry>();
                    TempData["Message"] = "Journal loaded successfully.";
                }
                else
                {
                    TempData["Message"] = "No saved journal file found.";
                }
            }
            catch (Exception ex)
            {
                TempData["Message"] = "Error loading journal: " + ex.Message;
            }
            return RedirectToAction("LoadJournal");
        }

        public IActionResult Edit(Guid id)
        {
            var entry = Entries.FirstOrDefault(e => e.Id == id);
            if (entry == null)
            {
                return NotFound();
            }
            return View(entry);
        }

        [HttpPost]
        public IActionResult Edit(Guid id, string response)
        {
            var entry = Entries.FirstOrDefault(e => e.Id == id);
            if (entry != null)
            {
                entry.Response = response;
                entry.Date = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                SaveJournal();
            }
            return RedirectToAction("LoadJournal");
        }

        public IActionResult Delete(Guid id)
        {
            Entries.RemoveAll(e => e.Id == id);
            SaveJournal();
            return RedirectToAction("LoadJournal");
        }

        private void SaveJournal()
        {
            try
            {
                string json = JsonConvert.SerializeObject(Entries, Formatting.Indented);
                System.IO.File.WriteAllText(FilePath, json);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error saving journal: " + ex.Message);
            }
        }

        private void LoadJournalEntries()
        {
            try
            {
                if (System.IO.File.Exists(FilePath))
                {
                    string json = System.IO.File.ReadAllText(FilePath);
                    Entries = JsonConvert.DeserializeObject<List<JournalEntry>>(json) ?? new List<JournalEntry>();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error loading journal: " + ex.Message);
            }
        }
    }
}
