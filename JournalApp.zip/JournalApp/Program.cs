// ===================================================
// Journal Application - Developed using Abstraction
// ===================================================
// This program allows users to create journal entries with prompts, 
// save them as JSON or CSV, edit and delete entries, and load saved data.
//
// Features exceeding requirements:
// ✅ CSV & JSON file support for saving and loading journal entries
// ✅ Edit and Delete journal entries
// ✅ Unique prompts system for new journal entries
// ✅ Timestamp for each journal entry
// ✅ Modern UI design improvements with color-coded options
// ===================================================

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();
var app = builder.Build();

app.UseStaticFiles();
app.UseRouting();
app.UseEndpoints(endpoints =>
{
    endpoints.MapControllerRoute(
        name: "default",
        pattern: "{controller=Journal}/{action=Index}/{id?}");
});

app.Run();
