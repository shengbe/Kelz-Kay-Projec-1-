using System;

namespace JournalApp.Models
{
    public class JournalEntry
    {
        public Guid Id { get; set; }
        public string Date { get; set; }
        public string Prompt { get; set; }
        public string Response { get; set; }
    }
}
